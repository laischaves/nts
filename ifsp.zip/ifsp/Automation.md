### Search
- [ ] Redes de Petri
- [ ] Description of devices used in automation
- [ ] ISA: International Standards for Automation: notes on instruments
and their definitions: TAGs


### Types of Automation
Industrial:
- Physical/Chemical Processes
- Manufacturing
- Use of PLC and several protocols

Comercial Buildings:
- "On board" equipment
- Different protocols

Movement automation:
- Processes such as assembling boxes, lifting
and such.
- Use of CNC, motion control, servomotors...

Equipment automation:
- Use of PLCs

### ISA Norms
- S5.1 is the ISA norm for definitions.




